import flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.min.css';
import Notiflix from 'notiflix';

let countdown = null;
let targetDate = null;

const startButton = document.querySelector('[data-start]');
startButton.disabled = true;

const options = {
  enableTime: true,
  time_24hr: true,
  defaultDate: new Date(),
  minuteIncrement: 1,
  onClose(selectedDates) {
    //Вибираємо останню дату перед закриванням
    targetDate = selectedDates[selectedDates.length - 1].getTime();
    // Превіряємо, чи правильно вибрана дата
    if (targetDate > Date.now()) {
      startButton.disabled = false;
    } else {
      Notiflix.Notify.failure('Please, choose date in future!');
      startButton.disabled = true;
    }
  },
};

flatpickr('#datetime-picker', options);

startButton.addEventListener('click', startTimer);

function convertMs(ms) {
  const second = 1000;
  const minute = second * 60;
  const hour = minute * 60;
  const day = hour * 24;

  const days = Math.floor(ms / day);
  const hours = Math.floor((ms % day) / hour);
  const minutes = Math.floor(((ms % day) % hour) / minute);
  const seconds = Math.floor((((ms % day) % hour) % minute) / second);

  return { days, hours, minutes, seconds };
}

// --------------------------- Функція запуску таймера ----------------------------
const timeUnits = ['days', 'hours', 'minutes', 'seconds'];
const timeElements = timeUnits.map(timeUnit =>
  document.querySelector(`.timer [data-${timeUnit}]`)
);

function startTimer() {
  startButton.disabled = true;

  countdown = setInterval(() => {
    const currentTime = Date.now();
    const remainingTime = targetDate - currentTime;

    if (remainingTime < 0) {
      clearInterval(countdown);
      Notiflix.Notify.success('Time is up!');
      startButton.disabled = false;
      return;
    }

    const remaining = convertMs(remainingTime);
    timeElements.forEach((timeElement, i) => {
      const value = remaining[timeUnits[i]].toString().padStart(2, '0');
      timeElement.textContent = value;
    });
  }, 1000);
}
